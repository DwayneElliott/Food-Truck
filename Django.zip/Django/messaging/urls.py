from django.urls import path
from .views import send_email_to_all_users
from .views import send_transactional_email

urlpatterns = [
    path('send-email/', send_email_to_all_users, name='send_email_to_all_users'),
    path('send_transactional_email/',send_transactional_email, name='send_transactional_email'),
]
