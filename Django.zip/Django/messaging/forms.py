from django import forms

class TransactionalEmailForm(forms.Form):

    to_name = forms.CharField(max_length=100)
    subject = forms.CharField(max_length=100)
    html_content = forms.CharField(widget=forms.Textarea)

