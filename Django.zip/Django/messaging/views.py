from __future__ import print_function
from django.core.mail import EmailMessage
from django.conf import settings
from django.template.loader import render_to_string
from django.http import HttpResponseServerError
from django.shortcuts import render
from django.contrib.auth.models import User
from django.core.mail import send_mail
from django.shortcuts import render
from django.conf import settings
from .forms import TransactionalEmailForm
import sib_api_v3_sdk
from sib_api_v3_sdk.rest import ApiException


def send_email_to_all_users(request):
    if request.method == 'POST':
        subject = request.POST.get('subject')
        message = request.POST.get('message')
        recipients = [user.email for user in User.objects.all()]
        email = EmailMessage(subject, message, settings.DEFAULT_FROM_EMAIL, recipients)
        email.content_subtype = 'html'

        # Attach the image file
        if 'image' in request.FILES:
            image_file = request.FILES['image']
            email.attach_file(image_file.name, image_file.read())

        email.send(fail_silently=False)
        return render(request, 'email_success.html')
    return render(request, 'send_email.html')


def send_transactional_email(request):
    if request.method == 'POST':
        form = TransactionalEmailForm(request.POST)
        if form.is_valid():
            configuration = sib_api_v3_sdk.Configuration()
            configuration.api_key['api-key'] = settings.SENDINBLUE_API_KEY

            api_instance = sib_api_v3_sdk.TransactionalEmailsApi(sib_api_v3_sdk.ApiClient(configuration))
            subject = form.cleaned_data['subject']
            sender = {"name":"Sendinblue","email":"contact@sendinblue.com"}
            reply_to = {"name":"Sendinblue","email":"contact@sendinblue.com"}
            html_content = form.cleaned_data['html_content']
            to_email = [user.email for user in User.objects.all()]
            to_name = form.cleaned_data['to_name']
            to = [{"email": to_email, "name": to_name}]
            send_smtp_email = sib_api_v3_sdk.SendSmtpEmail(to=to, reply_to=reply_to, html_content=html_content, sender=sender, subject=subject)

            try:
                api_response = api_instance.send_transac_email(send_smtp_email)
                print(api_response)
            except ApiException as e:
                print("Exception when calling SMTPApi->send_transac_email: %s\n" % e)
    else:
        form = TransactionalEmailForm()

    return render(request, 'send_transactional_email.html', {'form': form})

