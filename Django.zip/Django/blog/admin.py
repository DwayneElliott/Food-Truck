from django.contrib import admin
from .models import MenuItem, MenuItemSize, Order, CartItem

class MenuItemSizeInline(admin.TabularInline):
    model = MenuItemSize
    extra = 0

class MenuItemAdmin(admin.ModelAdmin):
    list_display = ('name', 'item_type')
    list_filter = ('item_type',)
    search_fields = ('name','item_type')
    inlines = [MenuItemSizeInline]

class CartItemInline(admin.TabularInline):
    model = CartItem
    extra = 0

class OrderAdmin(admin.ModelAdmin):
    list_display = ('user','date_ordered','updated_at','paid','checkout_session_id','total_price','status')
    list_filter = ('date_ordered','user')
    search_fields = ('user','date_ordered','updated_at','paid','checkout_session_id','total_price','status')
    inlines = [CartItemInline]

admin.site.register(MenuItem, MenuItemAdmin)
admin.site.register(Order,OrderAdmin)
admin.site.register(CartItem)

