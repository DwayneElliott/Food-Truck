from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import MenuItem, CartItem, Order, MenuItemSize
from django.urls import reverse
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
import stripe
from django.conf import settings
from django.db.models import Sum, F
from django.db import models
from django.db import transaction
from django.utils import timezone

def home(request):
    return render(request, 'home.html')


def about(request):
    return render(request, 'about.html')


def success(request):
    return render(request, 'success.html')

def cancel(request):
    return render(request, 'cancel.html')

def menu(request):
    menu_items = MenuItem.objects.filter(item_type='MENU')
    context = {'menu_items': menu_items}

    return render(request, 'menu.html', context)


def seasoning_menu(request):
    seasoning_items = MenuItem.objects.filter(item_type='SEASONING')
    context = {
        'seasoning_items': seasoning_items,
    }
    return render(request, 'seasoning.html', context)


def sauce_menu(request):
    sauce_items = MenuItem.objects.filter(item_type='SAUCE')
    context = {
        'sauce_items': sauce_items,
    }
    return render(request, 'sauce.html', context)


def catering_menu(request):
    catering_items = MenuItem.objects.filter(item_type='CATERING')
    context = {
        'catering_items': catering_items,
    }
    return render(request, 'catering.html', context)

def product_detail(request, item_id):
    menu_item = get_object_or_404(MenuItem, id=item_id)
    return render(request, 'product_detail.html', {'menu_item': menu_item})

@login_required
def add_to_cart(request, item_id):
    item = get_object_or_404(MenuItem, pk=item_id)
    if request.method == 'POST':
        quantity = int(request.POST['quantity'])
        size_id = request.POST.get('size')
        size = get_object_or_404(MenuItemSize, pk=size_id) if size_id else None

        if size:
            price = size.price
        else:
            price = item.sizes.first().price

        cart_item, created = CartItem.objects.get_or_create(user=request.user, item=item, item_size=size, price=price)
        if not created:
            cart_item.quantity += quantity
            cart_item.save()
        else:
            cart_item.quantity = quantity
            cart_item.save()
        messages.success(request, f"{quantity} x {item.name} added to cart.")
        return redirect('menu')
    else:
        sizes = item.sizes.all() if item.sizes.exists() else None
        return render(request, 'menu.html', {'menu_item': item, 'sizes': sizes})


@login_required
def remove_from_cart(request, cart_item_id):
    cart_item = get_object_or_404(CartItem, id=cart_item_id)

    # Check if the cart item belongs to the user
    if cart_item.user != request.user:
        messages.error(request, "You are not authorized to remove this item.")
        return redirect('cart')

    # Delete the cart item
    cart_item.delete()

    messages.success(request, "Item removed from cart.")
    return redirect('cart')


@login_required
def update_cart(request):
    if request.method == 'POST':
        for item_id, quantity in request.POST.items():
            if item_id.startswith('quantity_'):
                item_id = int(item_id.split('_')[1])
                quantity = int(quantity)
                cart_item = CartItem.objects.get(id=item_id)
                if quantity > 0:
                    cart_item.quantity = quantity
                    cart_item.save()
                else:
                    cart_item.delete()
        messages.success(request, 'Cart updated successfully!')
    return redirect(reverse('cart'))

@login_required
def cart(request):
    cart_items = CartItem.objects.filter(user=request.user)
    total = sum((item.item_size.price if item.item_size else 0) * item.quantity for item in cart_items)
    return render(request, 'cart.html', {'cart_items': cart_items, 'total': total})

@login_required
def order_history(request):
    orders = Order.objects.filter(user=request.user).order_by('-date_ordered')
    for order in orders:
        order.cart_items = CartItem.objects.filter(order=order)
    context = {'orders': orders}
    return render(request, 'order_history.html', context)

stripe.api_key = settings.STRIPE_SECRET_KEY

YOUR_DOMAIN = 'http://3.21.50.153:8000'

@transaction.atomic
def create_checkout_session(request):
    if request.method == 'POST':
        try:
            cart_items = CartItem.objects.filter(user=request.user)
            line_items = []
            total_price = 0
            for item in cart_items:
                line_items.append({
                    'price': item.item_size.stripe_price_id,
                    'quantity': item.quantity,
                })
                total_price += item.item_size.price * item.quantity

            # Create checkout session with line items and total price
            checkout_session = stripe.checkout.Session.create(
                payment_method_types=['card'],
                line_items=line_items,
                mode='payment',
                success_url=YOUR_DOMAIN + '/success',
                cancel_url=YOUR_DOMAIN + '/cancel',
                automatic_tax={'enabled': True},
            )

            # Create the order object
            order = Order.objects.create(
                user=request.user,
                date_ordered=timezone.now(),
                total_price=total_price,
                status='pending',
                paid=False,
                checkout_session_id=checkout_session.id
            )

            # Add the cart items to the order
            for item in cart_items:
                CartItem.objects.create(
                    order=order,
                    item=item.item,
                    price=item.item_size.price,
                    quantity=item.quantity
                )
            # Empty the user's cart
            cart_items.delete()

            return redirect(checkout_session.url)

        except Exception as e:
            return HttpResponse(str(e))

    return HttpResponseNotAllowed(['POST'])

@csrf_exempt
def complete_hook(request):
    # Retrieve the request body and the Stripe signature header
    payload = request.body
    sig_header = request.META['HTTP_STRIPE_SIGNATURE']
    event = None

    try:
        # Verify the Stripe signature
        event = stripe.Webhook.construct_event(payload, sig_header, secret=settings.STRIPE_WEBHOOK_SECRET)
    except ValueError as e:
        # Invalid payload
        return HttpResponse(status=400)
    except stripe.error.SignatureVerificationError as e:
        # Invalid signature
        return HttpResponse(status=400)

    # Handle the event
    if event.type == 'checkout.session.completed':
        session = event.data.object
        order = Order.objects.get(checkout_session_id=session.id)
        order.paid = True
        order.save()

    return HttpResponse(status=200)


