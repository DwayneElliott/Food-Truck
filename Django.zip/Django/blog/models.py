from django.db import models
from django.contrib.auth.models import User

class MenuItem(models.Model):
    MENU_ITEM_TYPES = (
        ('SEASONING', 'Seasoning'),
        ('SAUCE', 'Sauce'),
        ('CATERING', 'Catering'),
        ('MENU', 'Menu'),
    )


    id = models.BigAutoField(primary_key=True)
    name = models.CharField(max_length=255)
    image = models.ImageField(upload_to='menu_images/', blank=True, null=True)
    item_type = models.CharField(max_length=10, choices=MENU_ITEM_TYPES, default='MENU')

    def __str__(self):
        return self.name

class MenuItemSize(models.Model):
    MENU_ITEM_SIZE = (
        ('SMALL', 'Small'),
        ('MEDIUM', 'Medium'),
        ('LARGE', 'Large'),
    )

    size = models.CharField(max_length=10, choices=MENU_ITEM_SIZE, null=True, blank=True)
    description = models.TextField()
    price = models.DecimalField(default=0,decimal_places=2,max_digits=6)
    stripe_price_id = models.CharField(max_length=100, null=True)
    menu_item = models.ForeignKey(MenuItem, on_delete=models.CASCADE, related_name='sizes')

    def __str__(self):
        return self.menu_item.name + " - " + self.size if self.size else self.menu_item.name

class Order(models.Model):
    STATUS_CHOICES = [
        ('PENDING', 'Pending'),
        ('PROCESSED', 'Processed'),
        ('CANCELLED', 'Cancelled'),
    ]
    id = models.BigAutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    date_ordered = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    paid = models.BooleanField(default=False)
    checkout_session_id = models.CharField(max_length=255, blank=True, null=True)
    total_price = models.IntegerField(default=0)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')

    def __str__(self):
        return f"Order {self.id} - {self.user.get_full_name()}"

class CartItem(models.Model):
    id = models.BigAutoField(primary_key=True)
    item = models.ForeignKey(MenuItem, on_delete=models.CASCADE)
    item_size = models.ForeignKey(MenuItemSize, on_delete=models.CASCADE, null=True)
    quantity = models.PositiveIntegerField(default=1)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, default=None)
    price = models.IntegerField(default=0)
    order = models.ForeignKey(Order, on_delete=models.CASCADE, null=True, default=None, related_name='order')

    def __str__(self):
        return f"{self.quantity} x {self.item.name} for {self.user.username}"



