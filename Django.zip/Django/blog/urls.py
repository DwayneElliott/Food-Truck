from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('menu/', views.menu, name='menu'),
    path('seasoning/', views.seasoning_menu, name='seasoning_menu'),
    path('sauce/', views.sauce_menu, name='sauce_menu'),
    path('catering/', views.catering_menu, name='catering_menu'),
    path('about/', views.about, name='about'),
    path('product/<int:item_id>/', views.product_detail, name='product_detail'),
    path('add_to_cart/<int:item_id>/', views.add_to_cart, name='add_to_cart'),
    path('cart/', views.cart, name='cart'),
    path('remove_from_cart/<int:cart_item_id>/', views.remove_from_cart, name='remove_from_cart'),
    path('update_cart/', views.update_cart, name='update_cart'),
    path('order_history/', views.order_history, name='order_history'),
    path('create_checkout_session/', views.create_checkout_session, name='create_checkout_session'),
    path('success/', views.success, name ='success'),
    path('cancel/', views.success, name ='cancel'),
    path('complete_hook/', views.complete_hook, name='complete_hook'),
]

