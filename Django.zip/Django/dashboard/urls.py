from django.urls import path
from .views import owner_dashboard, update_order_status, menuitem_list, menuitem_detail, delete_menuitem, add_menuitem

urlpatterns = [
    path('', owner_dashboard, name='owner_dashboard'),
    path('update_order_status/<int:order_id>/', update_order_status, name='update_order_status'),
    path('menuitem_list/', menuitem_list, name='menuitem_list'),
    path('menuitem_detail/<int:pk>/', menuitem_detail, name='menuitem_detail'),
    path('delete_menuitem/<int:pk>/', delete_menuitem, name='delete_menuitem'),
    path('add_menuitem/', add_menuitem, name='add_menuitem'),
]
