from blog.models import Order, CartItem
from django.contrib.auth.decorators import user_passes_test
from django.shortcuts import get_object_or_404, render, redirect
from django.contrib import messages
from blog.models import MenuItem
from .forms import MenuItemForm
from django.shortcuts import redirect, render

#Displays customer orders
@user_passes_test(lambda u: u.is_superuser)
def owner_dashboard(request):
    orders = Order.objects.exclude(status__in=['PROCESSED', 'CANCELLED']).order_by('-date_ordered')
    for order in orders:
        order.cart_items = CartItem.objects.filter(order=order)
        order.user_name = order.user.get_full_name() if order.user else 'Anonymous'
    context = {'orders': orders}
    return render(request, 'owner_dashboard.html', context)


#Allows owner to update order status on daashboard
@user_passes_test(lambda u: u.is_superuser)
def update_order_status(request, order_id):
    order = get_object_or_404(Order, id=order_id)

    if request.user.is_superuser:
        if request.method == 'POST':
            status = request.POST.get('status')
            order.status = status
            order.save()
            messages.success(request, 'Order status updated successfully.')
            return redirect('owner_dashboard')

        return render(request, 'dashboard/update_order_status.html', {'order': order})

    # If user is not a superuser, redirect to home page
    return redirect('home')

#Displays all items
@user_passes_test(lambda u: u.is_superuser)
def menuitem_list(request):
    menuitems = MenuItem.objects.all()
    return render(request, 'menuitem_list.html', {'menuitems': menuitems})

#Allows owner to update item
@user_passes_test(lambda u: u.is_superuser)
def menuitem_detail(request, pk):
    menuitem = get_object_or_404(MenuItem, pk=pk)

    if request.method == 'POST':
        form = MenuItemForm(request.POST, request.FILES, instance=menuitem)
        if form.is_valid():
            menuitem = form.save(commit=False)
            menuitem.save()
            return redirect('menuitem_list')
    else:
        form = MenuItemForm(instance=menuitem)

    return render(request, 'menuitem_detail.html', {'form': form})

#Allows owner to delete items
@user_passes_test(lambda u: u.is_superuser)
def delete_menuitem(request, pk):
    menuitem = MenuItem.objects.get(pk=pk)
    if request.method == 'POST':
        menuitem.delete()
        messages.success(request, f'{menuitem.name} has been deleted!')
        return redirect('menuitem_list')
    context = {'menuitem': menuitem}
    return redirect(request, 'delete_menuitem.html', context)

@user_passes_test(lambda u: u.is_superuser)
def add_menuitem(request):
    if request.method == 'POST':
        form = MenuItemForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, 'Menu item added successfully.')
            return redirect('menuitem_list')
    else:
        form = MenuItemForm()

    return render(request, 'add_menu_item.html', {'form': form})
